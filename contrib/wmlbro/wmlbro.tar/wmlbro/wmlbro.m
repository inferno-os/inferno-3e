# vasil@vasil.com

WmlLib : module
{
	PATH : con "wmllib.dis";

	modinit			: fn();

	# used internally, might remove from interface
	removecomments	: fn(s : string) : string;
	tokenize		: fn(s : string) : list of string;
	parsewmltag		: fn(s : list of string) : (list of string, ref TagNode);

	buildtext		: fn(t : ref TagNode) : string;
	buildtextr		: fn(ind : string, t : ref TagNode) : string;
	parsetext		: fn(s : string) : (ref TagNode);
	buildbinary		: fn(t : ref TagNode) : array of byte;
	parsebinary		: fn(b : array of byte) : (ref TagNode);
	dumptree		: fn(indend : string, t : ref TagNode);
};

WMLEncode: module
{
	init			: fn(ctxt: ref Draw->Context, argv: list of string);
	modinit			: fn();
	encode			: fn(s : string) : array of byte;
};

WMLDecode: module
{
	init			: fn(ctxt: ref Draw->Context, argv: list of string);
	modinit			: fn();
	decode			: fn(b : array of byte) : string;
};
