#!/dis/sh
limbo -gw wmlbro.b
limbo -gw wmllib.b
limbo -gw wbmp.b
limbo -gw wmldecode.b
limbo -gw wmlencode.b
limbo -gw webgrab.b
