Webgrab: module
{
	PATH : con "webgrab.dis";

	init		: fn(ctxt: ref Draw->Context, argl: list of string);

	modinit		: fn();
	readconfig	: fn( );
	httpget		: fn(u: ref Url->ParsedUrl) : (string, array of byte, ref Url->ParsedUrl);
	getlastcontype	: fn() : string;
	setuseragent	: fn(s : string);
};
