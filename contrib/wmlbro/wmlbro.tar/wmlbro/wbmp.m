# vasil@vasil.com

Wbmp: module
{
	PATH : con "wbmp.dis";

	init	:	fn(ctxt: ref Draw->Context, argv: list of string);
	modinit :	fn();
	wbmp	:	fn(b : array of byte, top : ref Tk->Toplevel,
					where : string, id : int) : string;
};
