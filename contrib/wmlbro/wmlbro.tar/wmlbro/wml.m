# vasil@vasil.com

TagNode : adt 
{
	handle			: string;
	tag			:	byte;
	text			:	string;
#	text			:	list of string;
	attribs			:	cyclic list of	ref TagNode;
	subtags			:	cyclic list of ref TagNode;
	#getattr			:	fn(t : self ref TagNode, n : string) : string;
	getattr			:	fn(t : self ref TagNode, ttpye : byte) : string;
	getchild		:	fn(t : self ref TagNode, ttype : byte) : ref TagNode;
	getnthchild		:	fn(t : self ref TagNode, index : int) : ref TagNode;
	getnthattr		:	fn(t : self ref TagNode, index : int) : ref TagNode;
};

#    WML version Identifiers

VERSION_1_0			: con byte 16r00;
VERSION_1_1			: con byte 16r01;
VERSION_1_2			: con byte 16r02;
VERSION_1_3			: con byte 16r03;

#    Public Identifiers

PUBLIC_IN_STR_TABLE		: con byte 16r00;
PUBLIC_UNKNOWN			: con byte 16r01;
PUBLIC_1_0			: con byte 16r02;
PUBLIC_1_1			: con byte 16r04;
PUBLIC_1_2			: con byte 16r09;
PUBLIC_1_3			: con byte 16r0A;
PUBLIC_WTA_EVENT_1_0		: con byte 16r03;
PUBLIC_SI_1_0			: con byte 16r05;
PUBLIC_SL_1_0			: con byte 16r06;
PUBLIC_CO_1_0			: con byte 16r07;
PUBLIC_CHANNEL_1_1		: con byte 16r08;
PUBLIC_CHANNEL_1_2		: con byte 16r0D;
PUBLIC_PROV_1_0			: con byte 16r0B;
PUBLIC_WTA_1_2			: con byte 16r0C;

#    Language

LANGUAGE_ENGLISH		: con byte 16r19;

#    Character Sets

CHARSET_US_ACSII		: con byte 16r03;
CHARSET_UTF_8			: con byte 16r6A;

#	WML Global tokens

SWITCH_PAGE			: con byte 16r00;
END				: con byte 16r01;
ENTITY				: con byte 16r02;
STR_I				: con byte 16r03;
LITERAL				: con byte 16r04;
PI				: con byte 16r43;
LITERAL_C			: con byte 16r44;
STR_T				: con byte 16r83;
LITERAL_A			: con byte 16r84;
OPAQUE				: con byte 16rC3;
LITERAL_AC			: con byte 16rC4;

#	WML Global Extension tokens

EXT_I_0				: con byte 16r40;
EXT_I_1				: con byte 16r41;
EXT_I_2				: con byte 16r42;
EXT_T_0				: con byte 16r80;
EXT_T_1				: con byte 16r81;
EXT_T_2				: con byte 16r82;
EXT_0				: con byte 16rC0;	# reserved
EXT_1				: con byte 16rC1;	# reserved
EXT_2				: con byte 16rC2;	# reserved

#	Tag Tokens

TAG_MASK			: con byte 16r3F;
TAG_ATTRIBUTE_PRESENT_MASK	: con byte 16r80;
TAG_CONTENT_PRESENT_MASK	: con byte 16r40;

TAG_A				: con byte 16r1C;
TAG_ANCHOR			: con byte 16r22;
TAG_ACCESS			: con byte 16r23;
TAG_B				: con byte 16r24;
TAG_BIG				: con byte 16r25;
TAG_BR				: con byte 16r26;
TAG_CARD			: con byte 16r27;
TAG_DO				: con byte 16r28;
TAG_EM				: con byte 16r29;
TAG_FIELDSET			: con byte 16r2A;
TAG_GO				: con byte 16r2B;
TAG_HEAD			: con byte 16r2C;
TAG_I				: con byte 16r2D;
TAG_IMG				: con byte 16r2E;
TAG_INPUT			: con byte 16r2F;
TAG_META			: con byte 16r30;
TAG_NOOP			: con byte 16r31;
TAG_P				: con byte 16r20;
TAG_POSTFIELD			: con byte 16r21;
TAG_PRE				: con byte 16r1B;
TAG_PREV			: con byte 16r32;
TAG_ONEVENT			: con byte 16r33;
TAG_OPTGROUP			: con byte 16r34;
TAG_OPTION			: con byte 16r35;
TAG_REFRESH			: con byte 16r36;
TAG_SELECT			: con byte 16r37;
TAG_SETVAR			: con byte 16r3E;
TAG_SMALL			: con byte 16r38;
TAG_STRONG			: con byte 16r39;
TAG_TABLE			: con byte 16r1F;
TAG_TD				: con byte 16r1D;
TAG_TEMPLATE			: con byte 16r3B;
TAG_TIMER			: con byte 16r3C;
TAG_TR				: con byte 16r1E;
TAG_U				: con byte 16r3D;
TAG_WML				: con byte 16r3F;

#	Attribute Start Tokens

ATT_ACCEPT_CHARSET		: con byte 16r05;
ATT_ACCESSKEY			: con byte 16r5E;
ATT_ALIGN				: con byte 16r52;
ATT_ALIGN_BOTTOM			: con byte 16r06;
ATT_ALIGN_CENTER			: con byte 16r07;
ATT_ALIGN_LEFT			: con byte 16r08;
ATT_ALIGN_MIDDLE			: con byte 16r09;
ATT_ALIGN_RIGHT			: con byte 16r0A;
ATT_ALIGN_TOP			: con byte 16r0B;
ATT_ALT				: con byte 16r0C;
ATT_CACHE_CONTROL_NO_CACHE	: con byte 16r64;
ATT_CLASS				: con byte 16r54;
ATT_COLUMNS			: con byte 16r53;
ATT_CONTENT			: con byte 16r0D;
ATT_CONTENT_AVWW			: con byte 16r5C;	# application/vnd.wap.wmlc;charset=
ATT_DOMAIN			: con byte 16r0F;
ATT_EMPTYOK_FALSE			: con byte 16r10;
ATT_EMPTYOK_TRUE			: con byte 16r11;
ATT_ENCTYPE			: con byte 16r5F;
ATT_ENCTYPE_APP_X_W3_URLENCODED	: con byte 16r60;
ATT_ENCTYPE_MULTIPART_FORM_DATA	: con byte 16r61;
ATT_FORMAT			: con byte 16r12;
ATT_FORUA_FALSE			: con byte 16r56;
ATT_FORUA_TRUE			: con byte 16r57;
ATT_HEIGHT			: con byte 16r13;
ATT_HREF				: con byte 16r4A;
ATT_HREF_HTTP			: con byte 16r4B;
ATT_HREF_HTTPS			: con byte 16r4C;
ATT_HSPACE			: con byte 16r14;
ATT_HTTP_EQUIV			: con byte 16r5A;
ATT_HTTP_EQUIV_CONTENT_TYPE	: con byte 16r5B;
ATT_HTTP_EQUIV_EXPIRES		: con byte 16r5D;
ATT_ID				: con byte 16r55;
ATT_IVALUE			: con byte 16r15;
ATT_INAME				: con byte 16r16;
ATT_LABEL				: con byte 16r18;
ATT_LOCALSRC			: con byte 16r19;
ATT_MAXLENGTH			: con byte 16r1A;
ATT_METHOD_GET			: con byte 16r1B;
ATT_METHOD_POST			: con byte 16r1C;
ATT_MODE_NOWRAP			: con byte 16r1D;
ATT_MODE_WRAP			: con byte 16r1E;
ATT_MULTIPLE_FALSE		: con byte 16r1F;
ATT_MULTIPLE_TRUE			: con byte 16r20;
ATT_NAME				: con byte 16r21;
ATT_NEWCONTEXT_FALSE		: con byte 16r22;
ATT_NEWCONTEXT_TRUE		: con byte 16r23;
ATT_ONENTERBACKWARD		: con byte 16r25;
ATT_ONENTERFORWARD		: con byte 16r26;
ATT_ONPICK			: con byte 16r24;
ATT_ONTIMER			: con byte 16r27;
ATT_OPTIONAL_FALSE		: con byte 16r28;
ATT_OPTIONAL_TRUE			: con byte 16r29;
ATT_PATH				: con byte 16r2A;
ATT_SCHEME			: con byte 16r2E;
ATT_SENDREFERER_FALSE		: con byte 16r2F;
ATT_SENDREFERER_TRUE		: con byte 16r30;
ATT_SIZE				: con byte 16r31;
ATT_SRC				: con byte 16r32;
ATT_SRC_HTTP			: con byte 16r58;
ATT_SRC_HTTPS			: con byte 16r59;
ATT_ORDERED_TRUE			: con byte 16r33;
ATT_ORDERED_FALSE			: con byte 16r34;
ATT_TABINDEX			: con byte 16r35;
ATT_TITLE				: con byte 16r36;
ATT_TYPE				: con byte 16r37;
ATT_TYPE_ACCEPT			: con byte 16r38;
ATT_TYPE_DELETE			: con byte 16r39;
ATT_TYPE_HELP			: con byte 16r3A;
ATT_TYPE_PASSWORD			: con byte 16r3B;
ATT_TYPE_ONPICK			: con byte 16r3C;
ATT_TYPE_ONENTERBACKWARD		: con byte 16r3D;
ATT_TYPE_ONENTERFORWARD		: con byte 16r3E;
ATT_TYPE_ONTIMER			: con byte 16r3F;
ATT_TYPE_OPTIONS			: con byte 16r45;
ATT_TYPE_PREV			: con byte 16r46;
ATT_TYPE_RESET			: con byte 16r47;
ATT_TYPE_TEXT			: con byte 16r48;
ATT_TYPE_VND			: con byte 16r49;
ATT_VALUE				: con byte 16r4D;
ATT_VSPACE			: con byte 16r4E;
ATT_WIDTH				: con byte 16r4F;
ATT_XML_LANG			: con byte 16r50;
ATT_XML_SPACE_PRESERVE		: con byte 16r62;
ATT_XML_SPACE_DEFAULT		: con byte 16r63;

#	Attribute Value Tokens

VALUE_COM				: con byte 16r85;
VALUE_EDU				: con byte 16r86;
VALUE_NET				: con byte 16r87;
VALUE_ORG				: con byte 16r88;
VALUE_ACCEPT			: con byte 16r89;
VALUE_BOTTOM			: con byte 16r8A;
VALUE_CLEAR				: con byte 16r8B;
VALUE_DELETE			: con byte 16r8C;
VALUE_HELP				: con byte 16r8D;
VALUE_HTTP				: con byte 16r8E;
VALUE_HTTP_WWW			: con byte 16r8F;
VALUE_HTTPS				: con byte 16r90;
VALUE_HTTPS_WWW			: con byte 16r91;
VALUE_MIDDLE			: con byte 16r93;
VALUE_NOWARP			: con byte 16r94;
VALUE_ONENTERBACKWARD		: con byte 16r96;
VALUE_ONENTERFORWARD		: con byte 16r97;
VALUE_ONPICK			: con byte 16r95;
VALUE_ONTIMER			: con byte 16r98;
VALUE_OPTIONS			: con byte 16r99;
VALUE_PASSWORD			: con byte 16r9A;
VALUE_RESET				: con byte 16r9B;
VALUE_TEXT				: con byte 16r9D;
VALUE_TOP				: con byte 16r9E;
VALUE_UNKNOWN			: con byte 16r9F;
VALUE_WRAP				: con byte 16rA0;
VALUE_WWW				: con byte 16rA1;
